-- denormalizzo la lista dei mezzi con la portata mettendo poi il result set in una vista che utilizzer� per PBI
CREATE VIEW AA_VW_CAMION AS (
SELECT Codice_fornitore, Targa, Descrizione, c.Tipo_camion, Portata_kg, Descrizione_veicolo
FROM dim_camion AS c
LEFT OUTER JOIN dim_camion_caratteristiche AS cr ON c.Tipo_camion=cr.Tipo_camion
)
--creo anche una vista per la tabella fact dei servizi, cos� scelgo gi� le colonne
CREATE VIEW AA_VW_SERVIZI AS (
SELECT Data, Targa_mezzo, Anno_RIT_CNS, Prog_RIT_CNS, Ritiro_Consegna, Cod_mitt_dest, Numero_colli, Peso_lordo, Peso_tassato, Volume, Costo_Previsto
FROM rc_completo
)