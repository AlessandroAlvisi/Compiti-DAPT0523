-- Svolgo di seguito Task 2, creazione tabelle
-- So che le chiavi andrebbero definite a parte come constraint, ma voglio essere snello. Il progetto � molto lungo

CREATE TABLE Category (CategoryID VARCHAR(4) PRIMARY KEY, Description VARCHAR(50));
CREATE TABLE Region (RegionID VARCHAR(4) PRIMARY KEY, RDescription VARCHAR(50));
CREATE TABLE Product (ProductID VARCHAR(4) PRIMARY KEY, CategoryID VARCHAR(4) FOREIGN KEY REFERENCES Category(CategoryID), ProductName VARCHAR(50), UnitPrice DECIMAL(5,1));
CREATE TABLE State (StateID VARCHAR(6) PRIMARY KEY, StateName VARCHAR(50), Continent VARCHAR(50),RegionID VARCHAR(4) FOREIGN KEY REFERENCES Region(RegionID));
CREATE TABLE Sales (SalesID VARCHAR(10) PRIMARY KEY, SDate DATE, ProductID VARCHAR(4) FOREIGN KEY REFERENCES Product(ProductID),
RegionID VARCHAR(4) FOREIGN KEY REFERENCES Region(RegionID), Pieces INT, TotalCharge INT);

--Task 3: popolare le tabelle. Faccio 5 record a tabella, procedo come disegnato nella progettazione logica

INSERT INTO Category VALUES ('C1','Peluche'),('C2','Modellini'),('C3','Sport'),('C4','Action Figure'),('C5','Societ�');
INSERT INTO Region VALUES ('R1','West Europe'),('R2','South Europe'),('R3','North Europe'),('R4','North America'),('R5','South America');
INSERT INTO Product VALUES ('P1','C1','Orsacchiotto01',10),('P2','C2','Soldatini01',15),('P3','C3','Bicicletta05',250),('P4','C3','Skateboard01',50),
('P5','C5','Indovina Chi',20);
INSERT INTO State VALUES ('St1','Spagna','Europa','R1'),('St2','Francia','Europa','R1'),('St3','Italia','Europa','R2'),('St4','USA','America','R4'),
('St5','Argentina','America','R5');
INSERT INTO Sales VALUES ('S1','2024-01-10','P3','R1',1,250),('S2','2023-12-10','P2','R1',2,30),('S3','2023-02-10','P4','R2',1,50),
('S4','2022-10-20','P1','R2',2,20),('S5','2021-01-01','P1','R3',1,10);

-- andiamo a vedere se le tabelle sono come previsto

SELECT * FROM Category;
SELECT * FROM Region;
SELECT * FROM Product;
SELECT * FROM State;
SELECT * FROM Sales; -- sembra proprio di s�!

/*Task 4.1: Verificare che i campi definiti come PK siano univoci.
In altre parole, scrivi una query per determinare l�univocit� dei valori di ciascuna PK. Lo faccio solo su 1 tabella (Sales), per snellire */

SELECT COUNT(*) AS VerificaChiave, SalesID
FROM Sales
GROUP BY SalesID; --Confermato che SalesID � chiave, ogni valore da S1 a S5 compare 1 sola volta. Si poteva fare anche HAVING COUNT(*)>1 puntando al result set vuoto

/* Task 4.2: Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati pi� di 180 giorni dalla data vendita o meno 
(>180 -> True, <= 180 -> False)*/

SELECT SalesID, SDate, ProductName, Description, RDescription, CASE WHEN GG >180 THEN 'True' ELSE 'False' END AS Condizione
FROM(
SELECT q.*, DATEDIFF(DAY,SDate,GETDATE()) AS GG
FROM(SELECT SalesID, SDate, ProductName, Description, Rdescription
FROM Sales AS s
INNER JOIN Product AS p ON s.ProductID=p.ProductID
INNER JOIN Category AS c ON p.CategoryID=c.CategoryID
INNER JOIN Region AS r ON s.RegionID=r.RegionID) AS q) AS q1

-- NB: io ho messo la regione in relazione con la vendita, non lo stato! Non esiste associazione univoca vendita e nazione. Cercare lo stato produrrebbe pi� righe di ordini doppi.

-- Task 4.3: Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.

SELECT p.ProductID, ProductName, YEAR(SDate) AS Anno, SUM(Pieces) AS NPezzi, SUM(TotalCharge) AS TotAnno
FROM Product AS p
INNER JOIN Sales AS s ON p.ProductID=s.ProductID
GROUP BY p.ProductID, ProductName, YEAR(SDate)

-- Task 4.4: Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
-- Ribadisco: non esiste associazione diretta stato e vendita, la consegna NON era in questo senso (sebbene in effetti poco logico). Far� per nome regione

SELECT RDescription, YEAR(SDate) AS Anno, SUM(TotalCharge) AS TotAnno
FROM Sales AS s
INNER JOIN Region AS r ON s.RegionID=r.RegionID
GROUP BY RDescription, YEAR(SDate)
ORDER BY Anno DESC, TotAnno DESC

-- Task 4.5: Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?

SELECT Description, SUM(Pieces) AS Venduti 
FROM Sales AS s
INNER JOIN Product AS p ON s.ProductID=p.ProductID
INNER JOIN Category AS c ON p.CategoryID=c.CategoryID
GROUP BY Description
ORDER BY Venduti DESC -- I peluche sono i pi� richiesti dal mercato

-- Task 4.6: Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi 2 approcci

SELECT p.ProductId, ProductName
FROM Product AS p
LEFT OUTER JOIN Sales AS s ON p.ProductID=s.ProductID
WHERE SalesID IS NULL -- Indovina Chi non � mai stato venduto

SELECT p.ProductId, ProductName, SUM(PIECES) AS Venduti
FROM Product AS p
LEFT OUTER JOIN Sales AS s ON p.ProductID=s.ProductID
GROUP BY p.ProductId, ProductName
ORDER BY Venduti

-- Task 4.7: Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente).

SELECT p.ProductID, p.ProductName, MAX(SDate) AS LastDate
FROM Product AS p
LEFT OUTER JOIN Sales AS s ON p.ProductID=s.ProductID
GROUP BY p.ProductID, p.ProductName

-- Task 4.8: Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni utili (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW VW_AA_ProdottiDenormalizzato AS(
SELECT p.ProductID, p.ProductName, Description
FROM Product AS p
INNER JOIN Category AS c ON p.CategoryID=c.CategoryID) -- ricordando che "denormalizzare" � "impacchettare" in base a logiche comuni

--Task 4.9: Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche

CREATE VIEW VW_AA_StatiDenormalizzato AS (
SELECT StateID, StateName, Continent, RDescription
FROM State AS st
INNER JOIN Region AS r ON st.RegionID=r.RegionID)